package com.nt.dao;

import java.util.List;

import com.nt.domain.Person;

public interface PersonDAO {
	public int saveData();
    public List<Person> getPersonDetails(String desg);
}
