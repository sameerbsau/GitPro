package com.nt.test;

import java.util.List;

import com.nt.dao.PersonDAO;
import com.nt.dao.PersonDAOFactory;
import com.nt.domain.JobType;
import com.nt.domain.Person;
import com.nt.utility.HibernateUtil;

public class ComponentMappingTest {

	public static void main(String[] args) {
	  PersonDAO dao=null;
	  int cnt=0;
	  List<Person>list=null;
	  //get DAO
	  dao=PersonDAOFactory.getInstance();
	  //save data
	  //cnt=dao.saveData();
	  // Load data
	  list=dao.getPersonDetails("clerk");
	  for(Person person:list){
		  System.out.println("Person");
		   System.out.println(person.getPid()+"  "+person.getPname());
		  System.out.println("JOB Details");
		  JobType pjob=person.getPjob();
		  System.out.println(pjob.getDepartment()+"  "+pjob.getJob()+" "+pjob.getSalary());
	  }//for

	  //close objs
	  HibernateUtil.closeSession();
	  HibernateUtil.closeSessionFactory();
	}//main
}//class
