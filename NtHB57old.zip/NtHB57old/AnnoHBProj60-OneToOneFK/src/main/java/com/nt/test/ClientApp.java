package com.nt.test;

import com.nt.dao.OTOFKDAO;
import com.nt.dao.OTOFKDAOFactory;
import com.nt.utility.HibernateUtil;

public class ClientApp {

	public static void main(String[] args) {
		OTOFKDAO dao=null;
		//get DAO
		dao=OTOFKDAOFactory.getInstance();
		//save objs
		dao.saveDataUsingLicense();
		
		//close objs
		HibernateUtil.closeSession();
		HibernateUtil.closeSessionFactory();
	}//main
}//class
 