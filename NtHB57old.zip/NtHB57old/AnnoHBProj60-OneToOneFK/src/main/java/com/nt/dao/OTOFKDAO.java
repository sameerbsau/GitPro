package com.nt.dao;

public interface OTOFKDAO {
	public void saveDataUsingLicense();

}
