package com.nt.dao;

public class OTOFKDAOFactory {
	
	public static OTOFKDAO getInstance(){
		return new OTOFKDAOImpl();
	}

}
