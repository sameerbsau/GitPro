package com.nt.dao;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nt.domain.License;
import com.nt.domain.Person;
import com.nt.utility.HibernateUtil;

public class OTOFKDAOImpl implements OTOFKDAO {
	
	public void saveDataUsingLicense() {
		Session ses=null;
		Person person=null;
		License license=null;
		Transaction tx=null;
		//get Session
		ses=HibernateUtil.getSession();
		//create parent and child objs
		person=new Person();
		person.setFirstName("raja");
		person.setLastName("rao");
		person.setAge((byte)30);
		
		license=new License();
		license.setType("2-wheeler");
		license.setValidFrom(new Date());
		license.setValidTo(new Date(146,7,28));
		//set parent to child
		license.setLicenseHolder(person);
		//save obj
		try{
		  tx=ses.beginTransaction();
		    ses.save(license);
		  tx.commit();
		}//try
		catch(Exception e){
		  tx.rollback();
		}
		System.out.println("Object are saved");
	}//method
}//class
