package com.nt.domain;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "license")
public class License {
	@Id
	@GenericGenerator(name = "gen1", strategy = "sequence", parameters = @Parameter(name = "sequence_name", value = "lid_seq") )
	@GeneratedValue(generator = "gen1")
	private int lid;
	private String type;
	@Column(name = "validFrom")
	private Date validFrom;
	@Column(name = "validTo")
	private Date validTo;
	@OneToOne(targetEntity = Person.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "license_holder", referencedColumnName = "pid")
	private Person licenseHolder;

	public int getLid() {
		return lid;
	}

	public void setLid(int lid) {
		this.lid = lid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Date getValidFrom() {
		return validFrom;
	}

	public void setValidFrom(Date validFrom) {
		this.validFrom = validFrom;
	}

	public Date getValidTo() {
		return validTo;
	}

	public void setValidTo(Date validTo) {
		this.validTo = validTo;
	}

	public Person getLicenseHolder() {
		return licenseHolder;
	}

	public void setLicenseHolder(Person licenseHolder) {
		this.licenseHolder = licenseHolder;
	}

	@Override
	public String toString() {
		return "License [lid=" + lid + ", type=" + type + ", validFrom=" + validFrom + ", validTo=" + validTo + "]";
	}

	
}
