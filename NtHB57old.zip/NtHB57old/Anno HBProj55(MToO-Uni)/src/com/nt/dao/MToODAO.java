package com.nt.dao;

public interface MToODAO {
	public void saveChildsWithParent();
	public  void loadChildsAndTheirParent();

}
