package com.nt.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nt.domain.Department;
import com.nt.domain.EmpDetails;
import com.nt.utility.HibernateUtil;

public class MToODAOImpl implements MToODAO {

	@Override
	public void saveChildsWithParent() {
		Session ses=null;
		Department dept=null;
		Transaction tx=null;
		 EmpDetails emp1=null,emp2=null;
		//get Session
		 ses=HibernateUtil.getSession();
		 //parent 
		   dept=new Department();
		   dept.setDeptname("Accounts");
		   dept.setDepthead("SMITH");
		   //childs
		 emp1=new EmpDetails();
		 emp1.setEname("raja");
		 emp1.setSalary(8000);
		 emp1.setDept(dept);
		 
		 emp2=new EmpDetails();
		 emp2.setEname("ravi");
		 emp2.setSalary(9000);
		 emp2.setDept(dept);
		//set parent to childs
		emp1.setDept(dept);
		emp2.setDept(dept);
		
		
		try{
		 tx=ses.beginTransaction();
		  ses.save(emp1);ses.save(emp2);
		 tx.commit();
		 System.out.println("Object are saved");
		 }//try
		catch(Exception e){
		  tx.rollback();
		  }
	}//method
	
	@Override
	public void loadChildsAndTheirParent() {
		Session ses=null;
		List<EmpDetails> listEmps;
		Query query=null;
		Department dept=null;
		//get Session
		ses=HibernateUtil.getSession();
		//Load objs(chid to parent)
		query=ses.createQuery("from EmpDetails");
		listEmps=query.list();
		//process the reuslts
		/*for(EmpDetails ed:listEmps){
			System.out.println("child---->"+ed);
		   dept=ed.getDept();
		   System.out.println("parent---->"+dept);
		}//for*/ 
		
	}//method
	
	
}//class
