package com.nt.domain;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;
import org.hibernate.annotations.Parameter;

@Entity
public class EmpDetails{   //child
	 @Id
	 @GenericGenerator(name="gen1",
	                   strategy="sequence",
	                   parameters=@Parameter(name="sequence_name",
	                                         value="eno_seq"))
	 @GeneratedValue(generator="gen1")
	  private int eno;
	  private String ename;
	  private long salary;
	  @ManyToOne(targetEntity=Department.class,
			     cascade=CascadeType.ALL,
			     fetch=FetchType.EAGER)
      @LazyToOne(LazyToOneOption.PROXY)			     
	  @JoinColumn(name="deptno",referencedColumnName="deptno")
	  private Department dept;
	  
	  public EmpDetails() {
		System.out.println("EmpDetails:0-param constructor");
	}
	public int getEno() {
		return eno;
	}
	public void setEno(int eno) {
		this.eno = eno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public long getSalary() {
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	@Override
	public String toString() {
		return "EmpDetails [eno=" + eno + ", ename=" + ename + ", salary=" + salary + "]";
	}
	
	
	}