package com.nt.test;

import com.nt.dao.MToODAO;
import com.nt.dao.MToODAOFactory;
import com.nt.utility.HibernateUtil;

public class ClientApp {

	public static void main(String[] args)throws Exception {
		MToODAO dao=null;
		//get DAO
		 dao=MToODAOFactory.getInstance();
		 //dao.saveChildsWithParent();
		 dao.loadChildsAndTheirParent();
		//close objs
		HibernateUtil.closeSession();
		HibernateUtil.closeSessionFactory();
	}//main
}//class

