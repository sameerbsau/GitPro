package com.nt.dao;

import com.nt.domain.EmpDetails;

public interface EmpDAO {
	public void  insertEmpData();
	public void loadAndModify();
}
