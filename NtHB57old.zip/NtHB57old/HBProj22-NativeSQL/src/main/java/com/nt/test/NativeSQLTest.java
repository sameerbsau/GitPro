package com.nt.test;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nt.domain.EmpDetails;
import com.nt.utility.HibernateUtil;

public class NativeSQLTest {

	public static void main(String[] args) {
		Session ses=null;
		SQLQuery query=null;
		List<Object[]> list=null;
		List<EmpDetails> list1=null;
		// get Session
		ses=HibernateUtil.getSession();
		/*//create SQLQuery obj representing NativeSQL Query
		query=ses.createSQLQuery("select * from Employee");
		//execute Query
		list=query.list();
		//proess the Result
		for(Object row[]:list){
			for(Object val:row){
				System.out.print(val+" ");
			}//for
			System.out.println();
		}//for
		*/
		/*//create SQLQuery obj representing NativeSQL Query
			query=ses.createSQLQuery("select * from Employee");
			//map Enity Query result with Domain class
			query.addEntity(EmpDetails.class);
			  //peform pagination
			    query.setFirstResult(1);
			    query.setMaxResults(2);
				//execute Query
				list1=query.list();
				//proess the Result
				for(EmpDetails details:list1){
					System.out.println(details);
				}*/
	//execute Native SQL Select Scalar query
	/* query=
	 ses.createSQLQuery("select EID,FIRSTNAME from Employee WHERE EMAIL LIKE :dmn");
	 //map scalar cols with HB Data types
	 query.addScalar("EID",StandardBasicTypes.INTEGER);
	 query.addScalar("FIRSTNAME",StandardBasicTypes.STRING);
	 //set param values
	 query.setString("dmn","%xyz.com");
	 //execute query
	 list=query.list();
	 //process Results
	 for(Object[] row:list){
		 for(Object val:row){
			 System.out.print(val+" ");
			 System.out.print(val.getClass());
		 }//for
		 System.out.println();
	 }//for
*/	 
/*//execute Native SQL Select Scalar query with aggregate Results
query= ses.createSQLQuery("select count(*) from Employee");
//query.addScalar("count(*)",StandardBasicTypes.INTEGER);
List<Integer> list2=query.list();
int cnt=list2.get(0);
System.out.println("Emp count"+cnt);*/
		
 /*//Non-select Native SQL Query to insert record with direct values
   query=
     ses.createSQLQuery("insert into Employee values(:val1,:val2,:val3,:val4)");
   //set values to params
   query.setInteger("val1",1001);
   query.setString("val2","rajesh");
   query.setString("val3","rao");
   query.setString("val4","rao@gmail.com");
   Transaction tx=null;
   int count=0;
   try{
     tx=ses.beginTransaction();
	  count=query.executeUpdate();
	 tx.commit();
	 System.out.println("no.of records inserted::"+count);
   }//try
   catch(Exception e){
	   tx.rollback();
   }*/
		
		 /* Executing named Native SQL Query
		   Query query1=ses.getNamedQuery("GET_EMPS_BY_EMAIL");
		 query1.setString("dmn","%gmail.com");
		 list1=query1.list();
		  for(EmpDetails ed:list1){
		    System.out.println(ed);
		   }		
		*/
		/*//Executing named Native SQL Query
		 Query query1=ses.getNamedQuery("GET_DETAILS_BY_LASTNAME");
		   query1.setString("title","rao");
		   List<Object[]> lst=query1.list();
		  for(Object[] row:lst){
			  for(Object val:row){
				  System.out.print(val+" ");
			  }//for
			  System.out.println();
		  }//for
*/
		Query query1=ses.getNamedQuery("DELETE_EMPS_BY_EMAIL");
		query1.setString("domain","%gmail.com");
		 Transaction tx=null;
		  try{
		    tx=ses.beginTransaction();
		     int count=query1.executeUpdate();
		   tx.commit();
		    System.out.println("No.of records that are effected"+count);
		   }//try
		  catch(Exception e){
		    tx.rollback();
		   }
		
		
		//close objs
		HibernateUtil.closeSession();
		HibernateUtil.closeSessionFactory();
	}//main
}//class
