package com.nt.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nt.domain.EmpDetails;

public class LoadObjectTest {
	public static void main(String[] args) {
	
	Configuration cfg=null;
	SessionFactory factory=null;
	Session ses=null;
	Transaction tx=null;
	EmpDetails details=null;
	int idVal=0;
	//Activate HB framework
	cfg=new Configuration();
	//set confiuration properties
	cfg.setProperty("hibernate.connection.driver_class","oracle.jdbc.driver.OracleDriver");
	cfg.setProperty("hibernate.connection.url","jdbc:oracle:thin:@localhost:1521:xe");
	cfg.setProperty("hibernate.connection.username","system");
	cfg.setProperty("hibernate.connection.password","manager");
	cfg.setProperty("show_sql","true");

	cfg=cfg.configure("/com/nt/cfgs/hibernate.cfg.xml");

	
	//build SessionFactory
	factory=cfg.buildSessionFactory();
	// build SEssion
   ses=factory.openSession();
 
  //load obj/load record
   details=(EmpDetails)ses.get(EmpDetails.class, 1008);
     if(details!=null){
    	System.out.println(details);
    }
    else{
    	System.out.println("Record not found");
    }

    //close session
    ses.close();
    factory.close();
	}//main
}//class
