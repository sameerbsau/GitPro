package com.nt.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nt.domain.LibraryMembership;
import com.nt.domain.Student;
import com.nt.utility.HibernateUtil;

public class OToODAOImpl implements OToODAO {
	public void saveDataUsingStudent() {
		Session ses=null;
		Student raja=null;
		LibraryMembership rajaLib=null;
		Transaction tx=null;
		// get Session
		ses=HibernateUtil.getSession();
		//create parnet,child objs
		raja=new Student();
		raja.setSname("raja");
        raja.setAddress("hyd");
        
        rajaLib=new LibraryMembership();
        rajaLib.setJoiningDate(new Date(2010));
        //map parent to child and child to parent
        raja.setLibraryDetails(rajaLib);
        rajaLib.setStudentDetails(raja);
        //save data
        try{
         tx=ses.beginTransaction();
           ses.save(raja);
         tx.commit();
        }//try
        catch(Exception e){
          tx.rollback();
        }
        System.out.println("objs are saved...");
		
	}//method
	
	public void saveDataUsingLibraryMembership() {
		Session ses=null;
		Student ravi=null;
		LibraryMembership raviLib=null;
		Transaction tx=null;
		// get Session
		ses=HibernateUtil.getSession();
		//create parnet,child objs
		ravi=new Student();
		ravi.setSname("ravi");
        ravi.setAddress("hyd");
        
        raviLib=new LibraryMembership();
        raviLib.setJoiningDate(new Date());
        //map parent to child and child to parent
        ravi.setLibraryDetails(raviLib);
        raviLib.setStudentDetails(ravi);
        //save data
        try{
         tx=ses.beginTransaction();
           ses.save(raviLib);
         tx.commit();
        }//try
        catch(Exception e){
          tx.rollback();
        }
        System.out.println("objs are saved...");
		
	}//mehtid
	
}//class
