package com.nt.test;

import com.nt.dao.OToODAO;
import com.nt.dao.OToODAOFactory;
import com.nt.utility.HibernateUtil;

public class ClientApp {

	public static void main(String[] args) {
     OToODAO dao=null;		
		//get DAO
	 dao=OToODAOFactory.getInstance();
	   dao.saveDataUsingStudent();
	   dao.saveDataUsingLibraryMembership();
	 //close objs
	   HibernateUtil.closeSession();
	   HibernateUtil.closeSessionFactory();
	}
}
