package com.nt.dao;

public interface OToODAO {
   public void saveDataUsingStudent();
   public void saveDataUsingLibraryMembership();
   
}
