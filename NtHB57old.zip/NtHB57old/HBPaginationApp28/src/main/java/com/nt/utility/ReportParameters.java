package com.nt.utility;

public interface ReportParameters {
	public static final int PAGE_SIZE=2;

}
