package com.nt.dao;

import java.util.List;

import com.nt.domain.EmployeeHLO;

public interface EmployeeDAO {
	public int getEmployeeCount();
	public List<EmployeeHLO>  getReportData(int startPos);

}
