package com.nt.service;

import java.util.ArrayList;
import java.util.List;

import com.nt.dao.EmployeeDAO;
import com.nt.dao.EmployeeDAOFactory;
import com.nt.domain.EmployeeHLO;
import com.nt.dto.EmployeeDTO;
import com.nt.utility.ReportParameters;

public class EmployeeServiceImpl implements EmployeeService {

	public List<EmployeeDTO> showReportData(int pageNo) {
		int startPos=0;
		EmployeeDAO dao=null;
		List<EmployeeHLO> listHLO=null;
		List<EmployeeDTO> listDTO=null;
		EmployeeDTO dto=null;
		//generate StartPosition
		startPos=(pageNo*ReportParameters.PAGE_SIZE)-ReportParameters.PAGE_SIZE;
		// get Report Data (Use dAO)
		dao=EmployeeDAOFactory.getInstance();
		listHLO=dao.getReportData(startPos);
		//Convert ListHLO to listDTO
		listDTO=new ArrayList<EmployeeDTO>();
		
		for(EmployeeHLO hlo:listHLO){
			dto=new EmployeeDTO();
			dto.setEid(hlo.getEid());
			dto.setFirstname(hlo.getFirstName());
			dto.setLastname(hlo.getLastName());
			dto.setEmail(hlo.getEmail());
			listDTO.add(dto);
		}//for
		return listDTO;
	}//method
	
	public int getPageCount() {
		EmployeeDAO dao=null;
		int recordsCount=0;
		int pageCount=0;
		//get DAO
		dao=EmployeeDAOFactory.getInstance();
		//use DAO
		recordsCount=dao.getEmployeeCount();
		//get pages count
		pageCount=recordsCount/ReportParameters.PAGE_SIZE;
		if(recordsCount%ReportParameters.PAGE_SIZE!=0){
			pageCount++;
		}
		return pageCount;
		
	}
	
}
