package com.nt.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;

import com.nt.domain.EmployeeHLO;
import com.nt.utility.HibernateUtil;
import com.nt.utility.ReportParameters;

public class EmployeeDAOImpl implements EmployeeDAO {
	
	
	public int getEmployeeCount() {
		Session ses=null;
		Criteria criteria=null;
		Projection rowCount;
		List<Object> list=null;
		long count;
	  //get Session
		ses=HibernateUtil.getSession();
	  //Use QBC to get RowCount
		criteria=ses.createCriteria(EmployeeHLO.class);
		//prepare Projection
		rowCount=Projections.rowCount();
		//set Projection
		criteria.setProjection(rowCount);
		//execute QBC
		list=criteria.list();
		//get Result
		count=(Long)list.get(0);
		return ((int)count);
	}
	
	public List<EmployeeHLO> getReportData(int startPos) {
		Session ses=null;
		Criteria criteria=null;
		List<EmployeeHLO> list=null;
		// GET Session
		ses=HibernateUtil.getSession();
		//create Criteria obj
		criteria=ses.createCriteria(EmployeeHLO.class);
		//perform pagination
		criteria.setFirstResult(startPos);
		criteria.setMaxResults(ReportParameters.PAGE_SIZE);
		//execute QBC logic
		list=criteria.list();

		return list;
	}

}
