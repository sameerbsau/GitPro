package com.nt.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.nt.domain.EmpDetails;
import com.nt.utility.HibernateUtil;

public class FunctionDAOImpl implements FunctionDAO {
 @Override
public void getEmpDetailsByFirstNameInitChars(String initChars) {
	 Session ses=null;
	 Query query=null;
	 List<EmpDetails>list=null;
    //Get Session 
	 ses=HibernateUtil.getSession();
	//get Access to NamedNativeSQL Query
	 query=ses.getNamedQuery("EMP_DETAILS");
	 //set param value
	 query.setString(0,initChars+"%");
	 //execute (call pl/sql function)
	 list=query.list();
	 for(EmpDetails ed:list){
		 System.out.println(ed);
	 }
  }//method 
}//class

