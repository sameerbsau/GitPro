package com.nt.dao;

public class FunctionDAOFactory {
	public static FunctionDAO getInstance(){
		return new FunctionDAOImpl();
	}
}
