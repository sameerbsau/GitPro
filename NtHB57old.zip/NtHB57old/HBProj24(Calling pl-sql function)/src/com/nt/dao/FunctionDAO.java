package com.nt.dao;

public interface FunctionDAO {
  public void  getEmpDetailsByFirstNameInitChars(String initChars);
}
