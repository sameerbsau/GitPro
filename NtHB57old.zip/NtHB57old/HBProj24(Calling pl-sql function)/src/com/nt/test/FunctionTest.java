package com.nt.test;

import com.nt.dao.FunctionDAO;
import com.nt.dao.FunctionDAOFactory;
import com.nt.utility.HibernateUtil;

public class FunctionTest {

	public static void main(String[] args) {
		FunctionDAO dao=null;
	   //Get DAO
	   dao=FunctionDAOFactory.getInstance();
	   //call method
	   dao.getEmpDetailsByFirstNameInitChars("r");
	   
	   //close objs
	   HibernateUtil.closeSession();
	   HibernateUtil.closeSessionFactory();
		

	}

}
