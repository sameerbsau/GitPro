package com.nt.test;

import com.nt.dao.Proj_PrgmrDAO;
import com.nt.dao.Proj_PrgmrDAOFactory;
import com.nt.utility.HibernateUtil;

public class ClientApp {
	
	public static void main(String[] args) {
		Proj_PrgmrDAO dao=null;
		// get DAO
		dao=Proj_PrgmrDAOFactory.getInstance();
		//save data
		 //dao.saveData();
		//Load data
		dao.loadData();
		
		//close Session
		HibernateUtil.closeSession();
		//close SEssionFactory
		HibernateUtil.closeSessionFactory();
	}//main
}//class
