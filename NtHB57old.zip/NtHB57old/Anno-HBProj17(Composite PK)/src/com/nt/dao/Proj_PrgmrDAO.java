package com.nt.dao;

public interface Proj_PrgmrDAO {
	public void saveData();
	public void loadData();
	

}
