package com.nt.test;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nt.domain.Student;
import com.nt.utility.HibernateUtil;

public class NamedHQLTest {

	public static void main(String[] args) {
		Session ses=null;
		Query query1=null,query2=null;
		List <Student> list=null;
		Transaction tx=null;
		int count=0;
		//get Session
		ses=HibernateUtil.getSession();
		
		//Access Query for execution
		query1=ses.getNamedQuery("GET_STUDS_BY_RANGE");
		
		query1.setInteger("min",100);
		query1.setInteger("max",200);
		
		list=query1.list();
		
		for(Student st:list){
			System.out.println(st);
		}
		
		//Access Query for execution
		query2=ses.getNamedQuery("DELETE_STUDS_BY_ADDRS");
		
		query2.setString("addrs","hyd");
		
		try{
		 tx=ses.beginTransaction();
		   count=query2.executeUpdate();
         tx.commit();		
         System.out.println("No.of records that are effected"+count);
		}//try
		catch(Exception e){
			tx.rollback();
		}
		
		//close objs
		HibernateUtil.closeSession();
		HibernateUtil.closeSessionFactory();
		
		
		

	}

}
