package com.nt.dao;

public interface MToMDAO {
	public void saveData();
}
