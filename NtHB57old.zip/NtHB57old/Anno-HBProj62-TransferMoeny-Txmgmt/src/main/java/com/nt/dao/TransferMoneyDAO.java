package com.nt.dao;

public interface TransferMoneyDAO {
	
	public void transferMoney(int srcAcno,int destAcno,double amt)throws Exception;

}
