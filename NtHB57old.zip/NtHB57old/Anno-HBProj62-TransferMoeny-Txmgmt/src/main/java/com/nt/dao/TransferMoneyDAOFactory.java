package com.nt.dao;

public class TransferMoneyDAOFactory {
	
	public static TransferMoneyDAO getInstance(){
		return new TransferMoneyDAOImpl();
	}

}
