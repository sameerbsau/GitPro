package com.nt.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nt.utility.HibernateUtil;

public class TransferMoneyDAOImpl implements TransferMoneyDAO {
  private static final String WITHDRAW_QRY="UPDATE Account SET balance=balance-? WHERE acno=?";
  private static final String DEPOSITE_QRY="UPDATE Account SET balance=balance+? WHERE acno=?";
    
	
	public void transferMoney(int srcAcno, int destAcno, double amt)throws Exception {
		Session ses=null;
		Transaction tx=null;
		int result1=0,result2=0;
		Query query1=null,query2=null;
		//get Session 
		ses=HibernateUtil.getSession();
		//prepare  Query objs
		//for withdraw
		query1=ses.createQuery(WITHDRAW_QRY);
		query1.setDouble(0,amt);
		query1.setInteger(1,srcAcno);
		 //for deposite
		query2=ses.createQuery(DEPOSITE_QRY);
		query2.setDouble(0,amt);
		query2.setInteger(1,destAcno);
		
		
		//begin Tx
		try{
          tx=ses.beginTransaction();
           tx.setTimeout(60000);
           //execute Queries
           result1=query1.executeUpdate();
           result2=query2.executeUpdate();
           if(result1!=0 && result2!=0)
           tx.commit();
           else{
            tx.rollback();
             throw new Exception();
           }
		}//try
		catch(Exception e){
			tx.rollback();
			throw new Exception();
		}//catch
	}//method
}//class
