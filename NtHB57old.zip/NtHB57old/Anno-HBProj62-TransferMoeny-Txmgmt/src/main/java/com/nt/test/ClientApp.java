package com.nt.test;

import com.nt.dao.TransferMoneyDAO;
import com.nt.dao.TransferMoneyDAOFactory;
import com.nt.utility.HibernateUtil;

public class ClientApp {

	public static void main(String[] args) {
		TransferMoneyDAO dao=null;
		// get DAO
		dao=TransferMoneyDAOFactory.getInstance();
		try{
		  dao.transferMoney(101,102,3000);
		  System.out.println("Money Transfereed");
		}//try
		catch(Exception e){
			System.out.println("Money not Transfereed");
			e.printStackTrace();
		}
		//close objs
		HibernateUtil.closeSession();
		HibernateUtil.closeSessionFactory();
	}
}
