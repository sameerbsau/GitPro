package com.nt.dao;

public interface PaymentDAO {
	public void saveData();

}
