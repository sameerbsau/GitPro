package com.nt.test;

import java.util.List;

import com.nt.dao.FilterDAO;
import com.nt.dao.FilterDAOFactory;
import com.nt.domain.Student;
import com.nt.utility.HibernateUtil;

public class FilterTest {

	public static void main(String[] args) {
		FilterDAO dao=null;
		List<Student> list=null;
		//get DAO
		dao=FilterDAOFactory.getInstance();
		//Execute logic
		list=dao.getStudsByRange(100,200);
		//process the Reuslt
		for(Student st:list){
			System.out.println(st);
		}
		// close objs
		HibernateUtil.closeSession();
		HibernateUtil.closeSessionFactory();
	}//main
}//class
