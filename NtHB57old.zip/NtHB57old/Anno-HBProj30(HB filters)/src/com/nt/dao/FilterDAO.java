package com.nt.dao;

import java.util.List;

import com.nt.domain.Student;

public interface FilterDAO {
	public List<Student> getStudsByRange(int start,int end);

}
