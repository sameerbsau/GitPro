package com.nt.dao;

public class FilterDAOFactory {
	public static FilterDAO getInstance(){
		return new FilterDAOImpl();
	}

}
