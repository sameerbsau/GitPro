package com.nt.dao;

public interface OToMDAO {
	public void saveDataUsingUser();
	public void loadDataUsingUser();
	public void loadDataUsingUserWithQBC();
	public void deleteOnlyPhonesOfAUser();
	

}
