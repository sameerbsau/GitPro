package com.nt.dao;

public interface OToMDAO {
	public void saveDataUsingUser();
	

}
