package com.nt.service;

import java.util.List;

import com.nt.dto.StudentDTO;

public interface StudentService {
	
	public List<StudentDTO> retrieveAllStudents();
	public StudentDTO  getStudentDetails(int no);
	public String updateStudntDetails(StudentDTO dto);

}
