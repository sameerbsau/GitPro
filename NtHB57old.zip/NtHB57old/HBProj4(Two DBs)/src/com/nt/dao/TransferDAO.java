package com.nt.dao;

public interface TransferDAO {
	
	public boolean transferEmployee(int eid);

}
