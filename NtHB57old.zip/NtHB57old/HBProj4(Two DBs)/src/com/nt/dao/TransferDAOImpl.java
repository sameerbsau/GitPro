package com.nt.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nt.domain.EmpDetails;
import com.nt.utility.MySqlHibernateUtil;
import com.nt.utility.OracleHibernateUtil;

public class TransferDAOImpl implements TransferDAO {

	@Override
	public boolean transferEmployee(int eid) {
		Session oraSes=null,mysqlSes=null;
		EmpDetails details=null;
		Transaction tx=null; 
		boolean flag=false;
		//get Oracle Session
		oraSes=OracleHibernateUtil.getSession();
		//Load obj from Oracle
		details=(EmpDetails)oraSes.get(EmpDetails.class,eid);
		//save obj into mysql
		    // get MySql session
		   mysqlSes=MySqlHibernateUtil.getSession();
		     // save obj
		   try{
		    tx=mysqlSes.beginTransaction();
		       mysqlSes.save(details);
		    tx.commit();
		    flag=true;
		   }//try
		   catch(Exception e){
			   tx.rollback();
			   flag=false;
		   }
		   OracleHibernateUtil.closeSession();
		   MySqlHibernateUtil.closeSession();
		      
		return flag;
	}//method
}//class

