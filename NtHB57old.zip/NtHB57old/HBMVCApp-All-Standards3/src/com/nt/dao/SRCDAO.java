package com.nt.dao;

import com.nt.bo.StudentBO;

public interface SRCDAO {
  public int insert(StudentBO bo);
}
