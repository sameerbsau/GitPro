package com.nt.test;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nt.domain.Student;
import com.nt.utility.HibernateUtil;

public class BasicOperationsTest {

	public static void main(String[] args) {
		Session ses=null;
		Student st=null;
		//get Session
		ses=HibernateUtil.getSession();
		//create Domain class obj
		st=new Student();
		st.setSno(1002); st.setSname("raja");
		st.setAddress("hyd");
		Transaction tx=null;
		try{
		 tx=ses.beginTransaction();
		  int no=(Integer)ses.save(st);
		  System.out.println("Generated ID value"+no);
		  tx.commit();
		  System.out.println("Obj saved/record inserted");
		}//try
		catch(Exception e){
			tx.rollback();
		}
	
		HibernateUtil.closeSession();
		//close SessionFactory
		HibernateUtil.closeSessionFactory();
	}//main
}//class
