package com.nt.test;

import com.nt.dao.EmpDAO;
import com.nt.dao.EmpDAOFactory;
import com.nt.utility.HibernateUtil;

public class ClientApp {

	public static void main(String[] args) {
		EmpDAO dao=null;
		//get DAO
		 dao=EmpDAOFactory.getInstance();
		 //use Dao
		 //dao.insertEmpData();
		 dao.loadAndModify();
        //Close Session
         HibernateUtil.closeSession();
         //Close SessionFactory
         HibernateUtil.closeSessionFactory();
	}//main
}//class

