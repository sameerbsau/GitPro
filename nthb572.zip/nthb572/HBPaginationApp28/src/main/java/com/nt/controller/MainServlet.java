package com.nt.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nt.dto.EmployeeDTO;
import com.nt.service.EmployeeService;
import com.nt.service.EmployeeServiceImpl;

public class MainServlet extends HttpServlet {
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		int pageNo=0;
		EmployeeService service=null;
		List<EmployeeDTO> listDTO=null;
		int pagesCount=0;
		RequestDispatcher rd=null;
		// read pageNo
		pageNo=Integer.parseInt(req.getParameter("pageNo"));
		//Use Service class
		service=new EmployeeServiceImpl();
		listDTO=service.showReportData(pageNo);
		//get pagesCount
		pagesCount=service.getPageCount();
		//keep data in request attributes
		req.setAttribute("pageCount",pagesCount);
		req.setAttribute("reportData",listDTO);
		//forward the request
		rd=req.getRequestDispatcher("/report.jsp");
		rd.forward(req,res);
	}//doGet(-,-)
	
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		  doGet(req,res);
	}
}
