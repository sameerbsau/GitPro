package com.nt.dao;

import java.util.List;

public interface AttendenceDAO {

	public List<Object[]> calcAttendence(int no);
}
