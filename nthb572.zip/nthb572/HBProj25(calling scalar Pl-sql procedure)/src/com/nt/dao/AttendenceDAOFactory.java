package com.nt.dao;

public class AttendenceDAOFactory {
	
	public static AttendenceDAO getInstance(){
		return new AttendenceDAOImpl();
	}

}
