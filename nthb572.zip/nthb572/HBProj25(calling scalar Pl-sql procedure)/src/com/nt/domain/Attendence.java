package com.nt.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;



/*@Entity
@Table(name="attendence_sheet")
@NamedNativeQuery(name="attendence_details",
                  query="{call CALC_ATTENDENCE_PERCENTAGE(?,:sno)}")*/
                 
public class Attendence {
	//@Id
	private int stno;
	private String stname;
	private int twd;
	private int ndp;
	private float attendence_percentage;
	
	public int getStno() {
		return stno;
	}
	public void setStno(int stno) {
		this.stno = stno;
	}
	public String getStname() {
		return stname;
	}
	public void setStname(String stname) {
		this.stname = stname;
	}
	public int getTwd() {
		return twd;
	}
	public void setTwd(int twd) {
		this.twd = twd;
	}
	public int getNdp() {
		return ndp;
	}
	public void setNdp(int ndp) {
		this.ndp = ndp;
	}
	public float getAttendence_percentage() {
		return attendence_percentage;
	}
	public void setAttendence_percentage(float attendence_percentage) {
		this.attendence_percentage = attendence_percentage;
	}

}
