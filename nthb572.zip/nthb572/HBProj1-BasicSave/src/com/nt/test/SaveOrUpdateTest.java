package com.nt.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nt.domain.EmpDetails;

public class SaveOrUpdateTest {

	public static void main(String[] args) {
		
		Configuration cfg=null;
		SessionFactory factory=null;
		Session ses=null;
		Transaction tx=null;
		EmpDetails details=null,details1=null;
		int idVal=0;
		//Activate HB framework
		cfg=new Configuration();
		
		//read both HB cfg , mapping files
		cfg=cfg.configure("/com/nt/cfgs/hibernate.cfg.xml");
	   
		//build SessionFactory
		factory=cfg.buildSessionFactory();
		// build SEssion
	   ses=factory.openSession();
	   
	   //prepare obj
	   details=new EmpDetails();
	   details.setNo(1003);
	   details.setFname("ramesh");
	   details.setLname("rao3");
	   details.setMail("rao3@chari.com");
	   try{
		 tx=ses.beginTransaction();
		  details1=(EmpDetails)ses.merge(details);
		 tx.commit();
		 System.out.println("object is saved/updated");
		 System.out.println("The details are"+details1);
	   }//try	
	   catch(Exception e){
		   tx.rollback();
	   }
	   
	   //close Sesssion
	   ses.close();
	   //close SessionFactory
	   factory.close();
	}//main
}//class
