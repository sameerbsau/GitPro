package com.nt.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nt.domain.EmpDetails;

public class UpdateVsMergeTest {
	public static void main(String[] args) {
	
	Configuration cfg=null;
	SessionFactory factory=null;
	Session ses1=null,ses2=null;
	Transaction tx=null;
	EmpDetails details1=null,details2=null;;
	int idVal=0;
	//Activate HB framework
	cfg=new Configuration();
	
	//read both HB cfg , mapping files
	cfg=cfg.configure("/com/nt/cfgs/hibernate.cfg.xml");
   
	//build SessionFactory
	factory=cfg.buildSessionFactory();
	// build SEssion
   ses1=factory.openSession();
     details1=(EmpDetails)ses1.get(EmpDetails.class,1001); //pesistent state obj
     System.out.println(details1);
   ses1.close(); //detached obj
      details1.setMail("xxx4@yy2.com");
   
   ses2=factory.openSession();
      details2=(EmpDetails)ses2.get(EmpDetails.class, 1001);
      try{
    	  tx=ses2.beginTransaction();
    	   ses2.merge(details1);
    	   details1.setLname("chari2");
    	  tx.commit();
      }//try
      catch(Exception e){
    	  tx.rollback();
    	  e.printStackTrace();
      }
    
    //close session
       ses2.close();
    factory.close();
	}//main
}//class
