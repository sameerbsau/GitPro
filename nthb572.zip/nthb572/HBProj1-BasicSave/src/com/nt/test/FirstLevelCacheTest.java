package com.nt.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nt.domain.EmpDetails;

public class FirstLevelCacheTest {

	public static void main(String[] args) {

		Configuration cfg=null;
		SessionFactory factory=null;
		Session ses=null;
		Transaction tx=null;
		EmpDetails details1=null,details2=null,details3=null;
		int idVal=0;
		//Activate HB framework
		cfg=new Configuration();
		
		//read both HB cfg , mapping files
		cfg=cfg.configure("/com/nt/cfgs/hibernate.cfg.xml");
	   
		//build SessionFactory
		factory=cfg.buildSessionFactory();
		// build SEssion
	   ses=factory.openSession();
	
	 /*  //Load obj
	     //gets from DB s/w and puts in L1 cache
	   details1=(EmpDetails)ses.get(EmpDetails.class,1001);
	   System.out.println(details1);
	   //gets from L1 Cache
	   details2=(EmpDetails)ses.get(EmpDetails.class,1001);
	   System.out.println(details2);
	   
	    //ses.clear(); //empties the L1 cache
	     ses.evict(details1); //remove details1 obj from L1 cache1
	    
	   //get from Db s/w and puts L1 Cache
	   details3=(EmpDetails)ses.get(EmpDetails.class,1001);
	   System.out.println(details3);*/
	   
	   details1=(EmpDetails)ses.get(EmpDetails.class,1001);
	   try{
		   tx=ses.beginTransaction();
		    details1.setMail("raja@lion3.com");
		    ses.update(details1);
		    details1.setLname("chari4");
		    ses.update(details1);
		   tx.commit();
	   }//try
	   catch(Exception e){
		   tx.rollback();
	   }
	   
	   

	   
	   //close session
	   ses.close();
	   factory.close();
	}
}
