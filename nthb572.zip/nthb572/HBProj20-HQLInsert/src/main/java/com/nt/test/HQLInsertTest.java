package com.nt.test;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nt.utility.HibernateUtil;

public class HQLInsertTest {
	public static void main(String[] args) {
		Session ses=null;
		Query query=null;
		Transaction tx=null;
		int count=0;
		//Get Session
		ses=HibernateUtil.getSession();
		//prepare Query
		query=ses.createQuery("insert into NGOMember(no,fname,lname,mail) select no,fname,lname,mail from  EmpDetails where no>=:min and no<=:max");
		query.setInteger("min",100);
		query.setInteger("max",200);
		try{
		  tx=ses.beginTransaction();
		   count=query.executeUpdate();
		  tx.commit();
		 }//try
		catch(Exception e){
			tx.rollback();
		}
		System.out.println("no.of recors that are effected"+count);
		
		//close objs
		HibernateUtil.closeSession();
		HibernateUtil.closeSessionFactory();
	}//main
}//class
