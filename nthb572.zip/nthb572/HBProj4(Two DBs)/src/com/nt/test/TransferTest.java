package com.nt.test;

import com.nt.dao.TransferDAO;
import com.nt.dao.TransferDAOFactory;
import com.nt.utility.MySqlHibernateUtil;
import com.nt.utility.OracleHibernateUtil;

public class TransferTest {

	public static void main(String[] args) {
		TransferDAO dao=null;
		// get DAO
		dao=TransferDAOFactory.getInstance();
		//use DAO
		System.out.println("Emp Transfered?"+dao.transferEmployee(1010));
         //close Session Factory
		OracleHibernateUtil.closeSessionFactory();
		MySqlHibernateUtil.closeSessionFactory();
	}//main
}//class
