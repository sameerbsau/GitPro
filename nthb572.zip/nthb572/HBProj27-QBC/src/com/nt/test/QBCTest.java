package com.nt.test;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.nt.domain.EmpDetails;
import com.nt.utility.HibernateUtil;

public class QBCTest {
	public static void main(String[] args) {
		Session ses=null;
		// get Session
		ses=HibernateUtil.getSession();
		
		/*//create Criteria obj
		Criteria criteria=ses.createCriteria(EmpDetails.class);
		//execute QBC logic
		List<EmpDetails>list=criteria.list();
		//process List
		for(EmpDetails ed:list){
			System.out.println(ed);
		}//for
*/		
		/*//create CRiteria obj
		Criteria criteria=ses.createCriteria(EmpDetails.class);
		//prepare cond1
		Criterion cond1=Restrictions.between("no",100,400);
		criteria.add(cond1);
		//execute QBC logic
		List<EmpDetails>list=criteria.list();
		//process the Results
		for(EmpDetails ed:list){
			System.out.println(ed);
		}//for*/
		
   /* //create Criteria obj		
	Criteria criteria=ses.createCriteria(EmpDetails.class);
	//prepare conditions
	Criterion cond1=Restrictions.ge("no",100);
	Criterion cond2=Restrictions.le("no",500);
	Criterion cond3=Restrictions.like("mail","%gmail.com");
	//preparion andCondition
	Criterion andCond=Restrictions.and(cond1,cond2);
	Criterion orCond=Restrictions.or(andCond,cond3);
	//add condtion
	criteria.add(orCond);
	//execute QBC logic
	List<EmpDetails>list=criteria.list();
	//process the ResultSet
	for(EmpDetails ed:list){
	  System.out.println(ed);
	}*/
   
   /* //crete Criteria obj
	Criteria criteria=ses.createCriteria(EmpDetails.class);
	//prepre condition
	Criterion cond=Restrictions.sqlRestriction(" email like '%gmail.com'");
	//add condition
	criteria.add(cond);
	//execute QBC logic
	List<EmpDetails>list=criteria.list();
	//process the ResultSet
	for(EmpDetails ed:list){
	  System.out.println(ed);
	}*/

	/*//crete Criteria obj
	Criteria criteria=ses.createCriteria(EmpDetails.class);
	//prepare Order obj
	Order order=Order.desc("fname");
	//add order
	criteria.addOrder(order);
	//execute QBC logic
	List<EmpDetails>list=criteria.list();
	//process the Result
	for(EmpDetails ed:list){
		System.out.println(ed);
	}*/
  /*//create Criteria obj
	Criteria criteria=ses.createCriteria(EmpDetails.class);
   //create Projection objs
	Projection fname=Projections.property("fname");
	Projection lname=Projections.property("lname");
	//Add Projection objs to ProjectList
	ProjectionList pList=Projections.projectionList();
	pList.add(fname);pList.add(lname);
	//set ProjectionList to Crieria 
	criteria.setProjection(pList);
	//prepare condition
	Criterion cond=Restrictions.ilike("mail","%xyz.com");
	//add condtion
	criteria.add(cond);
	//prepare Order
	Order order=Order.desc("fname");
	//add Order
	criteria.addOrder(order);
	
	//execute QBC logic
	List<Object[]> list=criteria.list();
	for(Object[] row:list){
		for(Object val:row){
			System.out.print(val+"  ");
		}//for
		System.out.println();
	}//for
*/	
  //Working with Projections for aggragate operations
	/*	//create Criteria obj
    Criteria criteria =ses.createCriteria(EmpDetails.class);
     //Create Projections
     Projection rowCount=Projections.rowCount();
     Projection avg=Projections.avg("no");
     Projection max=Projections.max("no");
     Projection min=Projections.min("no");
      // Add Projections to ProjectionList
     ProjectionList pList=Projections.projectionList();
     pList.add(rowCount);
     pList.add(avg);
     pList.add(max);
     pList.add(min);
     //Add ProjectionList to Criteria 
     criteria.setProjection(pList);
     //execute QBC logic
     List<Object[]> list=criteria.list();
     //Process the List
     Object[] row=list.get(0);
     System.out.println("Row count"+row[0]);
     System.out.println("Avg of EID"+row[1]);
     System.out.println("Max of EID"+row[2]);
     System.out.println("Min of EID"+row[3]);
*/     
	//for Pagination
    Criteria criteria=ses.createCriteria(EmpDetails.class);
  //set pagination
      criteria.setFirstResult(4);
      criteria.setMaxResults(2);
  //execute QBC logic
  		List<EmpDetails>list=criteria.list();
  		
  		//process List
  		for(EmpDetails ed:list){
  			System.out.println(ed);
  		}//for
    
     
		//close objs
		HibernateUtil.closeSession();
		HibernateUtil.closeSessionFactory();
	}//main
}//class
