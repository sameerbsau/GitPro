package com.nt.dao;

public interface AuthenticationDAO {
	public String login(String username,String password);

}
