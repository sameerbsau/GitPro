package com.nt.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import org.hibernate.Session;
import org.hibernate.jdbc.ReturningWork;

import com.nt.utility.HibernateUtil;

public class AuthenticationDAOImpl implements AuthenticationDAO {
 private static String AUTH_QRY="{call P_AUTHENTICATION(?,?,?)}";
	
 @Override
	public String login(String username, String password) {
		Session ses=null;
		String result=null;
		//get Session
		ses=HibernateUtil.getSession();
		//call pl/sql procure
		result=ses.doReturningWork(new AuthJdbcReturningWork(username,password));
		
		return result;
	}
 private static class AuthJdbcReturningWork implements ReturningWork<String>{
	 private String username;
	 private String password;
	 public AuthJdbcReturningWork(String username,String password){
		this.username=username;
		this.password=password;
	 }
  @Override
  	public String execute(Connection con) throws SQLException {
	     CallableStatement cs=null;
	     String result;
  		//write jdbc code
	     cs=con.prepareCall(AUTH_QRY);
	    cs.registerOutParameter(3,Types.VARCHAR);
	    cs.setString(1,username);
	    cs.setString(2,password);
	     cs.execute();
	    result=cs.getString(3);
  		return result;
  	}//execute(-)	 
 }//inner class
}//outer class
