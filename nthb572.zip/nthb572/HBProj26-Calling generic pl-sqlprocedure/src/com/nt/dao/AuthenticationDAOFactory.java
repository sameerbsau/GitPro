package com.nt.dao;

public class AuthenticationDAOFactory {
	
	public static AuthenticationDAO getInstance(){
		return new AuthenticationDAOImpl();
	}

}
