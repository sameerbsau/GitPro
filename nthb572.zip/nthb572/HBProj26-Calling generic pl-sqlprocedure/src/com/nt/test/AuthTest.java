package com.nt.test;

import com.nt.dao.AuthenticationDAO;
import com.nt.dao.AuthenticationDAOFactory;
import com.nt.utility.HibernateUtil;

public class AuthTest {

	public static void main(String[] args) {
		AuthenticationDAO dao=null;
		//get DAO
		dao=AuthenticationDAOFactory.getInstance();
		System.out.println(dao.login("raja","rani"));
		
	//Close objs
	HibernateUtil.closeSession();
	HibernateUtil.closeSessionFactory();
	}

}
